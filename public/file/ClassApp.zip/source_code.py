#Menu
def menu():
	import os
	os.system("cls")
	program = "Keanggotaan Kelas Kodegakure"
	print(program.center(40))
	print("1 Daftar Anggota")
	print("2 Tambah Anggota")
	print("3 Cari Anggota")
	print("4 Perbarui Data Anggota")
	print("0 Keluar")
	pilih = int(input("Pilih menu <angka>: "))
	pilihan(pilih)
#Pilih
def pilihan(a):
	if a == 1:
		daftar()
	elif a == 2:
		tambah()
	elif a == 3:
		cari()
	elif a == 4:
		perbarui()
	elif a == 0:
		keluar()
	else:
		print("\nSilakan masukkan input yang sesuai", end = "")
#Menampilkan
def daftar():
	import os
	os.system("cls")
	print("<menampilkan daftar anggota>\n")
	f = open("data.txt","r")
	data = f.readlines()
	data.sort()
	if (len(data) == 0):
		print("Data belum tersedia")
	else:
		b = 1
		daftar = "Daftar Anggota Kelas Kodegakure"
		print(daftar.center(111))
		print(" --------------------------------------------------------------------------------------------------------------------- ")
		print("|","No".center(4),"|", "NIM".center(15),"|", "Nama".center(30),"|", "Jenis Kelamin".center(17),"|","Status".center(14),"|","Kontak".center(21),"|",end = "")
		print(" --------------------------------------------------------------------------------------------------------------------- ")
		for c in data:
			d = c.split("|")
			print("|",str(b)+".".center(3),"|",d[0].center(15),"|",d[1].center(30),"|",d[2].center(17),"|",d[3].center(14),"|",d[4].center(21),"|",end = "")
			b += 1
		print(" --------------------------------------------------------------------------------------------------------------------- ")
	f.close()
	print("\n\nTekan [Enter] untuk melanjutkan ", end = "")
	input()
	os.system('cls')
	menu()
#Menambah
def tambah():
	import os
	os.system("cls")
	print("<menambah daftar anggota>\n")
	tambah = "Tambah Daftar Anggota Kelas Kodegakure"
	print(tambah.center(111))
	nim = input("NIM		: ")
	nama = input("Nama		: ")
	kel = input("Jenis Kelamin	: ")
	stat = input("Status		: ")
	kontak = str(input("Kontak		: "))
	f = open("data.txt","a")
	data = f.writelines([nim,"|",nama,"|",kel.capitalize(),"|",stat,"|",kontak,"|\n"])
	f.close()
	print("\n\nTekan [Enter] untuk melanjutkan ", end = "")
	input()
	menu()
#Mencari
def cari():
	import os
	os.system("cls")
	print("<mencari data anggota>\n")
	print("1 NIM")
	print("2 Nama")
	print("3 Jenis Kelamin")
	print("4 Status")
	print("5 Kontak")
	cari = input("Cari berdasarkan <angka>: ")
	i = 0
	if cari == '1':
		nim = input("Masukkan NIM yang dicari: ")
		f = open("data.txt")
		data = f.readlines()
		for l in data:
			n = l.split("|")
			if (n[0]).find(nim):
				print("\nData Anggota Kelas Kodegakure Berhasil Ditemukan")
				print("\nNIM		: %s"%(n[0]))
				print("Nama		: %s"%(n[1]))
				print("Jenis Kelamin	: %s"%(n[2]))
				print("Status		: %s"%(n[3]))
				print("Kontak		: %s"%(n[4]))
				i += 1
		f.close()
	elif cari == '2':
		nama = input("Masukkan nama yang dicari: ")
		f = open("data.txt")
		data = f.readlines()
		for l in data:
			n = l.split("|")
			if (n[1]).find(nama):
				print("\nData Anggota Kelas Kodegakure Berhasil Ditemukan")
				print("\nNIM		: %s"%(n[0]))
				print("Nama		: %s"%(n[1]))
				print("Jenis Kelamin	: %s"%(n[2]))
				print("Status		: %s"%(n[3]))
				print("Kontak		: %s"%(n[4]))
				i += 1
		f.close()
	elif cari == '3':
		kel = input("Masukkan jenis kelamin yang dicari: ")
		f = open("data.txt")
		data = f.readlines()
		for l in data:
			n = l.split("|")
			if (n[2]).find(kel):
				print("\nData Anggota Kelas Kodegakure Berhasil Ditemukan")
				print("\nNIM		: %s"%(n[0]))
				print("Nama		: %s"%(n[1]))
				print("Jenis Kelamin	: %s"%(n[2]))
				print("Status		: %s"%(n[3]))
				print("Kontak		: %s"%(n[4]))
				i += 1
		f.close()
	elif cari == '4':
		status = input("Masukkan status yang dicari: ")
		f = open("data.txt")
		data = f.readlines()
		for l in data:
			n = l.split("|")
			if (n[3]).find(status) == status:
				print("\nData Anggota Kelas Kodegakure Berhasil Ditemukan")
				print("\nNIM		: %s"%(n[0]))
				print("Nama		: %s"%(n[1]))
				print("Jenis Kelamin	: %s"%(n[2]))
				print("Status		: %s"%(n[3]))
				print("Kontak		: %s"%(n[4]))
				i += 1
		f.close()
	elif cari == '5':
		kontak = input("Masukkan kontak yang dicari: ")
		f = open("data.txt")
		data = f.readlines()
		for l in data:
			n = l.split("|")
			if (n[4]).find(kontak):
				print("\nData Anggota Kelas Kodegakure Berhasil Ditemukan")
				print("\nNIM		: %s"%(n[0]))
				print("Nama		: %s"%(n[1]))
				print("Jenis Kelamin	: %s"%(n[2]))
				print("Status		: %s"%(n[3]))
				print("Kontak		: %s"%(n[4]))
				i += 1
		f.close()
	else:
		print("\nSilakan masukkan input yang sesuai", end = "")
	if i == 0:
		print("Data tidak ditemukan")
	print("\nTekan [Enter] untuk melanjutkan ", end = "")
	input()
	os.system('cls')
	menu()
#Memperbarui
def perbarui():
	import os
	os.system("cls")
	print("<memperbarui daftar anggota>\n")
	f = open("data.txt","r")
	data = f.readlines()
	data.sort()
	if (len(data) == 0):
		print("\nData belum tersedia")
		print("\n\nTekan [Enter] untuk melanjutkan ", end = "")
		input()
		os.system('clear')
		menu()
	else:
		b = 1
		daftar = "Daftar Anggota Kelas Kodegakure"
		print(daftar.center(111))
		for c in data:
			nama = c.split("|")
			print(nama[1])
			b += 1
	f.close()
	perbarui = input("Data siapa yang ingin diperbarui?\n")
	f = open("data.txt")
	data = f.readlines()
	index = 0
	i = 0
	for l in data:
		n = l.split("|")
		if (n[1].lower()).find(perbarui.lower())+1 >= 1:
			print("\nNIM		: %s"%(n[0]))
			print("Nama		: %s"%(n[1]))
			print("Jenis Kelamin	: %s"%(n[2]))
			print("Status		: %s"%(n[3]))
			print("Kontak		: %s"%(n[4]))
			yakin = input("Yakin ingin memperbarui data <y/n>? ")
			if yakin == 'y':
				nnim = input("\nNIM		: ")
				nnama = input("Nama		: ")
				nkel = input("Jenis Kelamin	: ")
				nstat = input("Status		: ")
				nkontak = str(input("Kontak		: "))
				n[0] = nnim
				n[1] = nnama
				n[2] = nkel
				n[3] = nstat
				n[4] = nkontak
				ndata = "|".join(n)
				data[index] = ndata
			i += 1
		index += 1
	if i == 0:
		print("Data tidak ditemukan")
	f.close()
	f = open("data.txt","w")
	data = f.writelines(data)
	f.close()
	f.close()
	print("\n\nTekan [Enter] untuk melanjutkan ", end = "")
	input()
	os.system('cls')
	menu()
#Keluar
import sys
def keluar():
	sys.exit()
#Jalankan
menu()
